import WeatherApp from "./WeatherApp";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <WeatherApp />
    </div>
  );
}
